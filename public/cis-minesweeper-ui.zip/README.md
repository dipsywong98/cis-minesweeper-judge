# Get started with UI

1. Install NodeJS and Yarn
2. `yarn install`
3. `yarn dev` and have fun at <http://localhost:5173/cis-minesweeper-ui>
